using NUnit.Framework;
using iq_api.Service;
using Microsoft.Extensions.Configuration;
using iq_api.CacheData;
using CallTimerAPI.Model;

using iq_api.Model;

namespace IQTest
{
    [TestFixture]
    public class Tests
    {
        public IConfiguration _config { get; }
        public SQLCacheConfig _cache;
        public DatabaseContext _dbcontext;

        public  IExchangeService _service;


        [SetUp]
        public void Setup()
        {
       
        }

        [Test]
        public void GoodTestMethod()
        {


            var res = new ExchangeService().httpResponseMessage("BTC");
            Assert.AreEqual(res, res);
        }
        [Test]
        public void BadTestMethod()
        { 
            var res =  new ExchangeService().httpResponseMessage("123333");
            Assert.AreEqual(res, res);
        }
    }
}