﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;


namespace UnitTestIQAPI
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GoodTestMethod()
        {
            var service = new ExchangeServervice();
            var res = service.GetExchangeRates("BTC");
            Assert.AreEqual(res, res);
        }
        [TestMethod]
        public void BadTestMethod()
        {
            var service = new ExchangeServervice();
            var res = service.GetExchangeRates(4554455454);
            Assert.AreEqual(res, res);
        }
    }
}
