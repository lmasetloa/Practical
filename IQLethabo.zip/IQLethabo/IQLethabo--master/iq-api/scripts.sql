CREATE DATABASE coinbase_db;
GO
USE coinbase_db;
GO
CREATE TABLE [dbo].Exchange_rate(
Id UNIQUEIDENTIFIER PRIMARY KEY default NEWID(),
Request varchar(255),
Response varchar(max),
)
GO
CREATE TABLE[dbo].[SQLCache](    
       [Id][nvarchar](449) NOT NULL,   
    [Value][varbinary](max) NOT NULL,   
    [ExpiresAtTime][datetimeoffset](7) NOT NULL,   
    [SlidingExpirationInSeconds][bigint] NULL,   
    [AbsoluteExpiration][datetimeoffset](7) NULL,   
    CONSTRAINT[pk_Id] PRIMARY KEY CLUSTERED([Id] ASC) WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)   
ON[PRIMARY]) ON[PRIMARY] TEXTIMAGE_ON[PRIMARY]  