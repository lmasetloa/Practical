using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using iq_api.Tools;
using Serilog;

namespace iq_api
{
    public class Program
    {
        private static IConfigurationRoot config = null;
        private static LoggerConfiguration serilogConfig = null;
        public static  void Main(string[] args)
        {
            try 
            {
                var confiFilePath = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName);

                config = new ConfigurationBuilder()
                    .SetBasePath(confiFilePath)
                    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                    .Build();

                Config.MySettings = new MySettings();
                config.GetSection("MySettings").Bind(Config.MySettings);

                serilogConfig = new LoggerConfiguration()
                    .WriteTo.File(
                        outputTemplate: "[{Timestamp:yyyy-MM-dd HH:mm:ss.fff} {Level:u3}] {Message:lj}{NewLine}{Exception}",
                        path: $"C:/Users/A101746/Documents/IQLethabo--master/IQLethabo--master/Logs/Log_.txt",
                        fileSizeLimitBytes: 5242880,
                        flushToDiskInterval: TimeSpan.FromSeconds(1),
                        rollOnFileSizeLimit: true,
                        rollingInterval: RollingInterval.Hour,
                        retainedFileCountLimit: 1000
                    );
                Log.Logger = serilogConfig.CreateLogger();
                Log.Information("Testing");

            }
            catch(Exception ex)
            {
                return ;
            }

            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
