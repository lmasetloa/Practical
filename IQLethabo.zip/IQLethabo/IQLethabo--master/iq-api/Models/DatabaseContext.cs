using iq_api.Model;
using Microsoft.EntityFrameworkCore;
namespace CallTimerAPI.Model{
    public class DatabaseContext:DbContext{
        public DatabaseContext(DbContextOptions<DatabaseContext> options): base(options)
        {
            
        }
        
        public DbSet<Info> Exchange_rate { get; set; }

    }
}
