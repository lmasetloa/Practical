


namespace iq_api.Model{
    public class Data {
        public string Currency { get; set; }
        public Rates Rates { get; set; }
    }
}