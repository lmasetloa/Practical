


namespace iq_api.Model{
    public class Rates {
        public string AED { get; set; }
        public string AFN { get; set; }
        public string ALL { get; set; }
        public string AMD { get; set; }
        public string ANG { get; set; }
        public string AOA { get; set; }
        public string ARS { get; set; }
        public string AUD { get; set; }
        public string AWG { get; set; }
    }
}