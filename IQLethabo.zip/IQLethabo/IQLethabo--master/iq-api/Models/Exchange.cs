


namespace iq_api.Model{
    public class Exchange {
        public string Id { get; set; }
        public Data Data { get; set; }
    }
}