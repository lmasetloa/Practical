


using System;

namespace iq_api.Model{
    public class Info {
        public Guid Id { get; set; }
        public string Request { get; set; }
        public string Response { get; set; }
  
    }
}