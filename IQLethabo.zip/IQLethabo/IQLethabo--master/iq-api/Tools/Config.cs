﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace iq_api.Tools
{
    public class Config
    {
        public static MySettings MySettings { get; set; }
    }

    public class MySettings
    {
        public string DbConnection { get; set; }
        public string coinbaseAPI { get; set; }

        public int CacheDuration { get; set; }
    }
}
