

using System;
using iq_api.Model;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;

namespace iq_api.CacheData{
    public class SQLCacheConfig
    {
        private IDistributedCache _memoryCache {get;set;}
        public SQLCacheConfig(IDistributedCache memoryCache){
            this._memoryCache = memoryCache;
        }
        public  void CacheExchange(Exchange exchange,int duration){
            var cacheOptions = new DistributedCacheEntryOptions{
              AbsoluteExpiration = DateTime.Now.AddMinutes(duration)
            };
            _memoryCache.SetString("Ex_Key",JsonConvert.SerializeObject(exchange),cacheOptions);
            
        }
        public Exchange GetExchange(){
            Exchange exchanges = new Exchange();
             var list = JsonConvert.DeserializeObject<Exchange>(_memoryCache.GetString("Ex_Key"));
            if(list != null){
                exchanges = list;
            }
            return exchanges;
        }
    }
}