



using iq_api.Model;

namespace iq_api.Service{
    public interface IExchangeService{
         Exchange GetExchangeRates(string currency);
    }
}