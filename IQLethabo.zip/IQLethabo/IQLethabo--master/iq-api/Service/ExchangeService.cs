


using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using CallTimerAPI.Model;
using iq_api.CacheData;
using iq_api.Model;
using iq_api.Tools;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;

namespace iq_api.Service{
    public class ExchangeService : IExchangeService {
        public IConfiguration _config = null;
        private SQLCacheConfig _cache;
        readonly DatabaseContext _dbcontext;
  

        public ExchangeService(IConfiguration config,SQLCacheConfig cache,DatabaseContext databaseContext){
            _config = config;
            _cache = cache;
            _dbcontext = databaseContext;

        }

        public ExchangeService()
        {
        }

        public HttpResponseMessage httpResponseMessage(string currency)
        {
            string url = "";


            if ((_config == null))
                url = "https://api.coinbase.com/v2/";
            else
                url = _config.GetSection("MySettings").GetSection("coinbaseAPI").Value;
            HttpClient client = new HttpClient();
            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            // Add the capability to retrieve the current exchange rate for only BitCoin(BTC) or Ethereum(ETH)
            HttpResponseMessage response = client.GetAsync("exchange-rates?currency=" + currency).Result;

            return response;
        }

        public Exchange GetExchangeRates(string currency){
            Exchange exchange = new Exchange();
            try 
            {

                var response = httpResponseMessage(currency);

                if (response.IsSuccessStatusCode)
                {
                    string responseString = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    var data = JsonConvert.DeserializeObject<Exchange>(responseString);
                    int min = int.Parse(_config.GetSection("MySettings").GetSection("CacheDuration").Value);
                    if (data != null)
                    {
                        var info = new Info();
                        // Implement caching of the exchange rate data for 1 minute.

                        _cache.CacheExchange(data, min);
                        //Save the user's request and the response in a database using your technologies of choice. Use code-first migrations
                        info.Request = data.Data.Currency;
                        info.Response = JsonConvert.SerializeObject(data.Data.Rates);
                        SaveDataInDB(info); // SQL Server db
                    }

                }
                var getCache = _cache.GetExchange(); // Get Saved cache data
                Log.Information(getCache.ToString());
            }
            catch( Exception ex)
            {
                Log.Error(ex.Message);
            }
          
           
             

             return exchange;

        }
        private void SaveDataInDB(Info info){
            try{
                if(info != null){
                     var entity = new Info{
                      Request = info.Request,
                      Response = info.Response
                  };
                 _dbcontext.Add(entity);
                _dbcontext.SaveChanges();

                }
                  
            }catch(Exception ex){
                Log.Error(ex.Message);

            }
        }

    }

}