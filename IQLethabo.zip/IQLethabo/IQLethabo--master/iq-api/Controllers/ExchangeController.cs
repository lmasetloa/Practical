
using iq_api.Service;
using Microsoft.AspNetCore.Mvc;

namespace iq_api.Controllers{
    [Route("api/[controller]")]
    public class ExchangeController : Controller{
        readonly IExchangeService _service;
        public ExchangeController(IExchangeService service)
        {
            _service = service;
        }
        [HttpGet]
        [Route("rates/{currency}")]
        public IActionResult GetExchangeRates([FromRoute]string currency){

            var result = _service.GetExchangeRates(currency);
            return Ok();
        }

        
    }
}